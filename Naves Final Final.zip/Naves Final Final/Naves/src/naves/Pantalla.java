package naves;

public class Pantalla {
	private int pantalla;
	public Pantalla(int pantalla) {
		this.pantalla = pantalla;
	}

	public int getPantalla() {
		return pantalla;
	}

	public void setPantalla(int panta) {
		pantalla = panta;
	}
}

